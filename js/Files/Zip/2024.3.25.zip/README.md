
# LonP Programming Language v.2024.3.25

edit main.lnp, then run main.py file  |  แก้ไขไฟล์ main.lnp แล้วรันไฟล์ main.py

