lnp = open("main.lnp", "r")
rf = lnp.read()

def remove_first_space_group(my_list):
    return [s.strip() for s in my_list]

def returnCode(coderf, sep):
    codes = []
    for code in coderf.split(sep)[:-1]: 
        codeVb = code.replace("\n", "")
        code_split = codeVb.split(":")
        #------------

        # print:( [\\] )/;
        if code_split[0] == "print" and code_split[1][0] == "(" and code_split[1][-1] == ")":
            codes.append(codeVb.replace(":", ""))
            continue

        # n:var:[\\] = [\\]/;
        if code_split[0] == "n" and code_split[1] == "var" and " = " in code_split[2]:
            codes.append(f"{code_split[2].split(' = ')[0]} = {code_split[2].split(' = ')[1]}")
            continue

        # ::using:module = [\\]/;
        if "using" in codeVb and "module" in codeVb and codeVb[:2] == "::":
            codes.append(f"import {codeVb.split(' = ')[1]}")
            continue

        #------------    
        try:
            codes.append(codeVb)
        except:
            continue
    return codes
#print(returnCode(rf, "/;"))
for k in returnCode(rf, "/;"):
    exec(k)